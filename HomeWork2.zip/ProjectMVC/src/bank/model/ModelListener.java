package bank.model;

public interface ModelListener {
	public void modelChanged(ModelEvent event);
}
