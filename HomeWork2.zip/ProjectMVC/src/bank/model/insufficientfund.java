package bank.model;

public class insufficientfund extends Exception {

}
