package bank.model;

import java.util.ArrayList;

public class AccountList {
	private ArrayList<AccountInfo> accList;
	
}
