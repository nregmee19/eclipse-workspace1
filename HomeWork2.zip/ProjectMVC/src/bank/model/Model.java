package bank.model;

public interface Model {
	void notifyChanged(ModelEvent e);
}
